﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

namespace winform_multithread
{
    public partial class Form1 : Form
    {
        TcpClient client; // socket client
        StreamWriter sw;  // streamWriter
        StreamReader sr;  // streamReader
        char[] charArray = new char[10000]; // read char array
        int ticks;
        int ticks_to_hint = 20;
        int ticks_end_time = 60;
        int port = Log_in.port;
        string user_name = Log_in.user_name;
        string user_password = Log_in.user_password;

        /// <summary>
        /// belongs to the share screens
        /// </summary>
        bool already_created = Log_in.already_created;
        public static Bitmap bmpScreenshot;
        public bool start = false;
        public static Graphics gfxScreenshot;
        int countRead = 0, countWrite = 0;

        public Form1()
        {
            InitializeComponent();
            // making the textbox always active for writing without pressing the mouse
            this.ActiveControl = textBox1;
            
            // opening communication with sockets to the python server
            client = new TcpClient();
            client.Connect(new IPEndPoint(IPAddress.Parse("192.168.1.28"), port));
            sw = new StreamWriter(client.GetStream()); sw.AutoFlush = true;
            sr = new StreamReader(client.GetStream());
            label1.Text = "connection established";
            My_name.Text = user_name;
            if (already_created == false)
            {
                listBox1.Items.Add("Which subject do you want to be testest on and how much study units?");
                listBox1.Items.Add("Input example for you--> English-4");
            }
            // Noam-pong3-Ready
            else
            {
                sw.WriteLine(My_name.Text + '-' + user_password + '-' + "Ready");
                listBox1.Items.Add("you may continue, " + user_name);
            }

            Console.WriteLine("ok");
            backgroundWorker1.RunWorkerAsync(sr);
        }

        //send click
        private void button_clicked(object sender, EventArgs e)
        {

            string msg = textBox1.Text;
        
            //checking the answer to which subject you are being tested
            if (listBox1.Items[0].ToString() == "Which subject do you want to be testest on and how much study units?" )
            {
                if (msg != "" && msg.Any(char.IsDigit))
                {
                    string subj = msg.Substring(0, msg.Length - 1);
                    int study_units = int.Parse(msg.Substring(msg.Length - 1));
                    Console.WriteLine(subj + "----------------><><" + study_units);

                    // history test
                    if (subj.Contains("history") || subj.Contains("History"))
                    {
                        if (study_units >= 3 && study_units <= 5)
                        {
                            listBox1.Items.Clear();
                            listBox1.Items.Add("History");
                            // register-Noam-History-5
                            string send = "register" + '-' + My_name.Text + '-' + "History" + '-' + (study_units).ToString();
                            Console.WriteLine("sended --" + send);
                            sw.WriteLine(send);
                        }

                        else
                            listBox1.Items.Add("The study units need to be between 3 to 5");



                    }

                    // english test
                    else if (subj.Contains("english") || subj.Contains("English"))
                    {
                        if (study_units >= 3 && study_units <= 5)
                        {
                            listBox1.Items.Clear();
                            listBox1.Items.Add("English");
                            // register-Noam-English-5
                            string send = "register" + '-' + My_name.Text + '-' + "English" + '-' + (study_units).ToString();
                            Console.WriteLine("sended --" + send);
                            sw.WriteLine(send);
                        }

                        else
                            listBox1.Items.Add("The study units need to be between 3 to 5");


                    }

                    //wrong input of subject
                    else
                        listBox1.Items.Add("There is not such a subject, please try again");
                }

                else
                    listBox1.Items.Add("Wrong, please try again");
            }

            //checking the answer to how much study units 
            /*else if (listBox1.Items[1].ToString() == "English:how much study units do you learn? ")
            {

                int study_units = int.Parse(msg);
                if (study_units >= 3 && study_units <= 5)
                    sw.WriteLine( My_name.Text+ '-' + "study_units-" + msg);
                else
                    listBox1.Items.Add("The study units need to be between 3 to 5");

            }*/

            // if the user desire a hint
            else if ( msg== "yes hint")
            {
                if (ticks > 8)
                    sw.WriteLine(My_level.Text + "-" + listBox1.Items[1] + "-" + textBox1.Text ) ;
                else
                    listBox1.Items.Add("Try yourself a bit more");
            }
            

            // sending regular msg, example: "History:1-which year did....-1939-Noam
            else
                sw.WriteLine(My_level.Text+ "-" + listBox1.Items[1]+ "-" + textBox1.Text + "-" + My_name.Text );

            textBox1.Text = "";

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e) // receive msg
        {
            StreamReader sr = e.Argument as StreamReader; // get streamReader argument from runWorkerAsync
            var data = "";
            var readByteCount = 0;
            string[] words;  string subj; string level;string ques_num; string question;
          

            do {

                readByteCount = sr.Read(charArray, 0, charArray.Length);

                if (readByteCount > 0) {

                    data = new string(charArray, 0, readByteCount);

                    //Invoke(new Action(() => listBox1.Items.Add("server: " + data)));
                    if (data.Contains("Right") || data.Contains("Wrong"))
                    {
                        Invoke(new Action(() => listBox1.Items.Clear()));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else if (data == "bye")
                    {
                        Invoke(new Action(() => label1.Text = "connection terminated"));
                        Invoke(new Action(() => listBox1.Items.Add("you lost your time, you are out")));
                        Invoke(new Action(() => textBox1.Enabled=false));
                        client.Close();
                    }

                    else if (data == "you have to choose one of the shown answers... believe me one of them is right :)")
                    {
                        Invoke(new Action(() => listBox1.Items.Add("")));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else if (data.Contains("givenhint") )
                    {
                        ticks_end_time = ticks_end_time + 5;
                        data = data.Split('-')[1];
                        Invoke(new Action(() => listBox1.Items.Add("")));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else if (data.Contains("No hints given"))
                    {                      
                        Invoke(new Action(() => listBox1.Items.Add("")));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else
                    {
                        words = data.Split('-');
                        subj = words[0];
                        level = words[1];
                        ques_num = words[2];
                        question = words[3];

                        for (int i = 0; i < words.Length; i++)
                        {
                            Console.WriteLine("Words-->" + words[i]);

                        }
                        Console.WriteLine(data);
                        Console.WriteLine("Time "+words[words.Length - 1]);
                        if (words[words.Length - 1] != (ticks_to_hint).ToString() )
                            ticks_to_hint = int.Parse ( words[words.Length - 1] );


                        Invoke(new Action(() => My_level.Text = subj + "-" + level));
                        Invoke(new Action(() => listBox1.Items.Add(ques_num + question)));

                        for (int i = 4; i < words.Length-1; i++)
                        {
                            Invoke(new Action(() => listBox1.Items.Add(" ")));
                            Invoke(new Action(() => listBox1.Items.Add(words[i])));

                        }

                        ticks = 0;
                        Invoke(new Action(() => timer1.Start()));
                        



                    }



                }
                else Thread.Sleep(100);
                Console.WriteLine(data);
                }   
            while (data != "bye");
            Invoke(new Action(() => label1.Text = "connection terminated"));
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e) {
            client.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ticks++;
            if (ticks == ticks_to_hint)
            {
                listBox1.Items.Add("");
                listBox1.Items.Add("I see that you are having a little trouble");
                listBox1.Items.Add("if you would like a hint send yes hint");
            }

            else if (ticks== ticks_end_time)
                {
                    sw.WriteLine("time-end-error");
                }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                button_clicked( sender, e);
        }
//-------------------------------------------------------------------------------------------------------------------- share screens

        /// <summary>
        /// connection making
        /// </summary>
        private void Connect()
        {

            Console.WriteLine("start client");
            TcpClient TCPC = new TcpClient();
            TCPC.Connect("192.168.1.28", 60001);
            if (TCPC.Connected)
            {
                //Console.WriteLine("client connected");
                this.client = TCPC;
                this.recievingWorker.RunWorkerAsync();
                this.sendingWorker.RunWorkerAsync();
            }
        }
        public void fillpic()
        { // screen shot taken by client and displayed on picturebox
            //Console.WriteLine("fillpic");

            bmpScreenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
            gfxScreenshot = Graphics.FromImage(bmpScreenshot);
            gfxScreenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
        }

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        { // image to byte array - client to server
            countWrite++;
            //Console.WriteLine("save to byte array {0}", countWrite);
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
        }

        private void recievingWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            NetworkStream ns;
            byte[] data;
            while (true)
            {
                ns = this.client.GetStream();
                fillpic(); // take screenshot
                if (ns.CanWrite)
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    data = imageToByteArray(bmpScreenshot);
                    bf.Serialize(ns, data);
                    // ns.Write(data, 0, data.Length);
                    //Console.WriteLine("bytearray sent to server {0}", data.Length);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.button2.Enabled = false;
            //this.button2.Enabled = true;
            /////// connection made
            this.Connect();
        }

        private void sendingWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                NetworkStream netStream = this.client.GetStream();
                if (netStream.DataAvailable)
                {
                    Console.WriteLine("data available");
                    byte[] bytes = new byte[this.client.ReceiveBufferSize]; // Reads NetworkStream into a byte buffer. / client.ReceiveBufferSize = 8192
                    //netStream.Read(bytes, 0, (int)client.ReceiveBufferSize); // return anything from 0 to numBytesToRead.
                    //imageFromByteArray(bytes);

                    using (MemoryStream ms = new MemoryStream())
                    {

                        //---- //Invoke(new Action(() => listBox1.Items.Add("server: " + data)));

                        BinaryFormatter bf = new BinaryFormatter();
                        byte[] bytesToSend = (byte[])bf.Deserialize(netStream);
                        //byte[] bytesToSend = ms.ToArray();
                        Console.WriteLine("calling imageFromByteArray with bytesTosend {0}", bytesToSend.Length);
                        ControlMessage message = ControlMessage.FromBytes(bytesToSend);

                        Rectangle resolution = Screen.PrimaryScreen.Bounds;

                    }
                }
            }
        }

        
    }
}
