﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

namespace winform_multithread
{
    public partial class Form1 : Form
    {
        TcpClient client; // socket client
        StreamWriter sw;  // streamWriter
        StreamReader sr;  // streamReader
        char[] charArray = new char[10000]; // read char array
        int ticks;
        int ticks_to_hint = 10;
        int ticks_end_time = 80;
        int port = Log_in.port;
        string user_name = Log_in.user_name;
        //string user_password = Log_in.user_password;
        string[] words;


        /// <summary>
        /// belongs to the share screens
        /// </summary>
        bool already_created = Log_in.already_created;
        public static Bitmap bmpScreenshot;
        public bool share = false;
        public static Graphics gfxScreenshot;
        int countRead = 0, countWrite = 0;
        TcpClient share_screen;

        public Form1(TcpClient client_log)
        {
            InitializeComponent();
            // making the textbox always active for writing without pressing the mouse
            this.ActiveControl = textBox1;

            // opening communication with sockets to the python server

            //client = new TcpClient();
            //client.Connect(new IPEndPoint(IPAddress.Parse("192.168.1.29"), port));
            this.client = client_log;
            sw = new StreamWriter(client.GetStream()); sw.AutoFlush = true;
            sr = new StreamReader(client.GetStream());
            label1.Text = "connection established";
            My_name.Text = user_name;

            if (already_created == false)
            {
                listBox1.Items.Add("Which subject do you want to be testest on and how much study units?");
                listBox1.Items.Add("Input example for you--> English-4");
            }
            // Noam-pong3-Ready
            else
            {
                sw.WriteLine(My_name.Text + '-' + "Ready");
                button2.Enabled = true;
            }

            Console.WriteLine("ok");
            //listBox1.DrawMode = DrawMode.OwnerDrawVariable;
            backgroundWorker1.RunWorkerAsync(sr);

        }

        //send click
        private void button_clicked(object sender, EventArgs e)
        {

            string msg = textBox1.Text;
        
            //checking the answer to which subject you are being tested
            if (listBox1.Items[0].ToString() == "Which subject do you want to be testest on and how much study units?" )
            {
                if (msg != "" && msg.Any(char.IsDigit))
                {
                    string subj = msg.Substring(0, msg.Length - 1);
                    int study_units = int.Parse(msg.Substring(msg.Length - 1));
                    Console.WriteLine(subj + "----------------><><" + study_units);

                    // history test
                    if (subj.Contains("history") || subj.Contains("History"))
                    {
                        if (study_units >= 3 && study_units <= 5)
                        {
                            listBox1.Items.Clear();
                            listBox1.Items.Add("History");
                            // register-Noam-History-5
                            string send = "register" + '-' + My_name.Text + '-' + "History" + '-' + (study_units).ToString();
                            Console.WriteLine("sended --" + send);
                            sw.WriteLine(send);
                            button2.Enabled = true;
                            textBox2.Text = "";
                        }

                        else
                            listBox1.Items.Add("The study units need to be between 3 to 5");



                    }

                    // english test
                    else if (subj.Contains("english") || subj.Contains("English"))
                    {
                        if (study_units >= 3 && study_units <= 5)
                        {
                            listBox1.Items.Clear();
                            listBox1.Items.Add("English");
                            // register-Noam-English-5
                            string send = "register" + '-' + My_name.Text + '-' + "English" + '-' + (study_units).ToString();
                            Console.WriteLine("sended --" + send);
                            sw.WriteLine(send);
                            button2.Enabled = true;
                            textBox2.Text = "";
                        }

                        else
                            listBox1.Items.Add("The study units need to be between 3 to 5");


                    }

                    //wrong input of subject
                    else
                        listBox1.Items.Add("There is not such a subject, please try again");
                }

                else
                    listBox1.Items.Add("Wrong, please try again");
            }

            //checking the answer to how much study units 
            /*else if (listBox1.Items[1].ToString() == "English:how much study units do you learn? ")
            {

                int study_units = int.Parse(msg);
                if (study_units >= 3 && study_units <= 5)
                    sw.WriteLine( My_name.Text+ '-' + "study_units-" + msg);
                else
                    listBox1.Items.Add("The study units need to be between 3 to 5");

            }*/

            else if (words.Length > 4)
            {
                bool flag = false;

                for (int i = 4; i < words.Length - 1; i++)
                {
                    // sending regular msg, example: "History:1-which year did....-1939-Noam
                    if (words[i] == msg)
                    {
                        sw.WriteLine(My_level.Text + "-" + listBox1.Items[1] + "-" + msg + "-" + My_name.Text);
                        flag = true;
                        break;
                    }
                }

                if ( flag == false)
                {
                    listBox1.Items.Add("");
                    listBox1.Items.Add("you have to choose one of the shown answers... believe me one of them is right :)");
                }

                textBox1.Text = "";

            }


          
                

            

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e) // receive msg
        {
            StreamReader sr = e.Argument as StreamReader; // get streamReader argument from runWorkerAsync
            var data = "";
            var readByteCount = 0;
            string msg;
            string subj; string level;string ques_num; string question;
          

            do {

                readByteCount = sr.Read(charArray, 0, charArray.Length);

                if (readByteCount > 0) {

                    data = new string(charArray, 0, readByteCount);
                    Console.WriteLine(data);

                    //Invoke(new Action(() => listBox1.Items.Add("server: " + data)));
                    if (data.Contains("Right") || data.Contains("Wrong"))
                    {
                        Invoke(new Action(() => listBox1.Items.Clear()));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else if (data == "bye" )
                    {
                        share = false;
                        Invoke(new Action(() => label1.Text = "connection terminated"));
                        Invoke(new Action(() => listBox1.Items.Add("you lost your time, you are out")));
                        Invoke(new Action(() => textBox1.Enabled=false));
                        Invoke(new Action(() => button1.Enabled = false));
                        Invoke(new Action(() => button2.Enabled = false));
                        Invoke(new Action(() => button3.Enabled = false));
                        client.Close();
                        timer1.Stop();
                    }

                    else if (data.Contains("End_test"))
                    {
                        share = false;
                        Invoke(new Action(() => label1.Text = "connection terminated"));
                        Invoke(new Action(() => listBox1.Items.Add("The test is over")));
                        Invoke(new Action(() => textBox1.Enabled = false));
                        Invoke(new Action(() => button1.Enabled = false));
                        Invoke(new Action(() => button2.Enabled = false));
                        Invoke(new Action(() => button3.Enabled = false));
                        client.Close();
                        timer1.Stop();
                    }

                    else if (data == "not_registered")
                    {
                        already_created = false;
                        Invoke(new Action(() => listBox1.Items.Clear() ));
                        Invoke(new Action(() => listBox1.Items.Add("Which subject do you want to be testest on and how much study units?")));       
                        Invoke(new Action(() => listBox1.Items.Add("Input example for you--> English-4") ));
                    }



                   /* else if (data == "you have to choose one of the shown answers... believe me one of them is right :)")
                    {
                        Invoke(new Action(() => listBox1.Items.Add("")));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }*/

                    else if (data.Contains("givenhint") )
                    {
                        ticks_end_time = ticks_end_time + 5;
                        data = data.Split('-')[1];
                        Invoke(new Action(() => listBox1.Items.Add("")));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else if (data.Contains("No hints given"))
                    {                      
                        Invoke(new Action(() => listBox1.Items.Add("")));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                    }

                    else if (data.Contains("Shutdown"))
                    {
                        msg = "connection terminated for you, the program will be closed after you press ok";
                        string title = "Admin message";
                        MessageBox.Show(msg, title);
                        Invoke(new Action(() => Application.Exit() ));  

                    }

                    //examle: "activate_share_screen-63000"
                    else if (data.Contains("activate_share_screen"))
                    {
                        int p1 = int.Parse( (data.Split('-')[1]) );                      
                        this.Connect(p1);
                        msg = "The admin is seeing your screen, behave nice";
                        string title = "Admin message";
                        MessageBox.Show(msg, title);
                    }

                    //  wxmaple: "Admin_msg-Is everything ok?"
                    else if (data.Contains("Admin_msg-"))
                    {
                        int lan = listBox2.Items.Count;
                        msg = data.Split('-')[1];
                        Invoke(new Action(() => listBox2.Items.Add("Admin: " + msg )));
                    }

                    //example: "User_chat_all-Noam-I am ok" 
                    else if (data.Contains("User_chat_all-"))
                    {
                        if ( checkBox2.Checked == true )
                        {
                            string name = data.Split('-')[1];
                            msg = data.Split('-')[2];
                            Invoke(new Action(() => listBox2.Items.Add(name + ':' + msg)));
                        }
             
                    }

                  

                    else
                    {
                        Invoke(new Action(() => textBox1.Text = ""  ));
                        
                        words = data.Split('-');
                        subj = words[0];
                        level = words[1];
                        ques_num = words[2];
                        question = words[3];

                        if (already_created == true)
                            Invoke(new Action(() => listBox1.Items.Add("you may continue")  ));
                            already_created = false;

                        //Console.WriteLine(data);
                        Console.WriteLine("Time "+words[words.Length - 1]);
                        if (words[words.Length - 1] != (ticks_to_hint).ToString() )
                            ticks_to_hint = int.Parse ( words[words.Length - 1] );


                        Invoke(new Action(() => My_level.Text = subj + "-" + level));
                        Invoke(new Action(() => listBox1.Items.Add(ques_num + question)));

                        for (int i = 4; i < words.Length-1; i++)
                        {
                            Invoke(new Action(() => listBox1.Items.Add(" ")));
                            Invoke(new Action(() => listBox1.Items.Add(words[i])));

                        }

                        ticks = 0;
                        Invoke(new Action(() => timer1.Start()));
                        Invoke(new Action(() => button3.Enabled = false ));




                    }



                }
                else Thread.Sleep(100);
                Console.WriteLine(data);
                }   
            while (data != "bye");
            Invoke(new Action(() => label1.Text = "connection terminated"));
        }


        //-------------------------------------------------------------------------------------------------------------------- share screens

        /// <summary>
        /// connection making
        /// </summary>
        private void Connect(int p1)
        {

            Console.WriteLine("start client- share screen");
            TcpClient TCPC = new TcpClient();
            TCPC.Connect("192.168.1.29", p1);
            if (TCPC.Connected)
            {
                Console.WriteLine("connected to admin for sharing screen");
                share_screen = TCPC;
                share = true;
                this.recievingWorker.RunWorkerAsync();
                this.sendingWorker.RunWorkerAsync();
            }
        }

        public void fillpic()
        { // screen shot taken by client and displayed on picturebox
            //Console.WriteLine("fillpic");

            bmpScreenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
            gfxScreenshot = Graphics.FromImage(bmpScreenshot);
            gfxScreenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
        }

        public byte[] imageToByteArray(System.Drawing.Image imageIn)
        { // image to byte array - client to server
            countWrite++;
            //Console.WriteLine("save to byte array {0}", countWrite);
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
        }

        private void recievingWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            NetworkStream ns;
            byte[] data;
            while (share)
            {
                ns = share_screen.GetStream();
                fillpic(); // take screenshot
                if (ns.CanWrite)
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    data = imageToByteArray(bmpScreenshot);
                    bf.Serialize(ns, data);
                    Console.WriteLine("Sleep for 2 seconds.");
                    Thread.Sleep(2000);

                    /*                    byte[] text = Encoding.ASCII.GetBytes("to_admin_");
                                        byte[] send = new byte[text.Length + data.Length];
                                        Array.Copy(text, 0, send, 0, text.Length);
                                        Array.Copy(data, 0, send, text.Length, data.Length);*/
                    // send

                    //ns.Write(send, 0, send.Length);
                    //Console.WriteLine("bytearray sent to server {0}", data.Length);
                }
            }
        }


        private void sendingWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (share)
            {
                NetworkStream netStream = share_screen.GetStream();
                if (netStream.DataAvailable)
                {

                    byte[] bytes = new byte[share_screen.ReceiveBufferSize]; // Reads NetworkStream into a byte buffer. / client.ReceiveBufferSize = 8192
                    //netStream.Read(bytes, 0, (int)client.ReceiveBufferSize); // return anything from 0 to numBytesToRead.
                    //imageFromByteArray(bytes);

                    using (MemoryStream ms = new MemoryStream())
                    {

                        //---- //Invoke(new Action(() => listBox1.Items.Add("server: " + data)));

                        BinaryFormatter bf = new BinaryFormatter();
                        byte[] bytesToSend = (byte[])bf.Deserialize(netStream);
                        //byte[] bytesToSend = ms.ToArray();
                        Console.WriteLine("calling imageFromByteArray with bytesTosend {0}", bytesToSend.Length);
                        ControlMessage message = ControlMessage.FromBytes(bytesToSend);

                        Rectangle resolution = Screen.PrimaryScreen.Bounds;

                    }
                }
            }
        }

        private void recievingWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            share_screen.Close();
        }

        private void sendingWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            share_screen.Close();
        }

  //-------------------------------------------------------------------------------------------------------------------- 

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e) {
            client.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ticks++;
            if (ticks == ticks_to_hint)
            {
                listBox1.Items.Add("");
                listBox1.Items.Add("I see that you are having a little trouble");
                listBox1.Items.Add("if you would like a hint- click on the Hint button");
                button3.Enabled = true;
            }

            else if (ticks== ticks_end_time)
                {
                    sw.WriteLine("time-end-error");
                }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                button_clicked( sender, e);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string msg = textBox2.Text;
            string destination;
            listBox2.Items.Add("You: " + msg);

            if (checkBox1.Checked == false)
                destination = "User_chat-";
            else
                destination = "User_chat_all-";


            sw.WriteLine(destination + My_name.Text + "-" + msg);
        }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                textBox1.Text = listBox1.SelectedItem.ToString();
                this.ActiveControl = textBox1;
            }


        }

        private void listBox1_DrawItem(object sender, DrawItemEventArgs e)
        {
            if(e.Index < 0) return;
            //if the item state is selected them change the back color
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                e = new DrawItemEventArgs(e.Graphics,
                                          e.Font,
                                          e.Bounds,
                                          e.Index,
                                          e.State ^ DrawItemState.Selected,
                                          e.ForeColor,
                                          Color.Yellow);//Choose the color

            // Draw the background of the ListBox control for each item.
            e.DrawBackground();
            // Draw the current item text
            e.Graphics.DrawString(listBox1.Items[e.Index].ToString(), e.Font, Brushes.Black, e.Bounds, StringFormat.GenericDefault);
            // If the ListBox has focus, draw a focus rectangle around the selected item.
            e.DrawFocusRectangle();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ticks > 8)
                sw.WriteLine(My_name.Text + "-" + My_level.Text + "-" + listBox1.Items[1] + "-yes hint");
            else
                listBox1.Items.Add("Try yourself a bit more");
        }

        
    }
}
