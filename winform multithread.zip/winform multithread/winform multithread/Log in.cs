﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;

namespace winform_multithread
{
    public partial class Log_in : Form
    {

        TcpClient client; // socket client
        StreamWriter sw;  // streamWriter
        StreamReader sr;  // streamReader
        char[] charArray = new char[10000]; // read char array
        public static string user_password="";
        public static string user_name="";
        public static int port = 53881;
        public static bool already_created = false;

        public Log_in()
        {
            InitializeComponent();

            client = new TcpClient();
            client.Connect(new IPEndPoint(IPAddress.Parse("192.168.1.29"), port));
            sw = new StreamWriter(client.GetStream()); sw.AutoFlush = true;
            sr = new StreamReader(client.GetStream());
            backgroundWorker1.RunWorkerAsync(sr);
            this.ActiveControl = textBox1;
            //this.ActiveControl = textBox2;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            StreamReader sr = e.Argument as StreamReader; // get streamReader argument from runWorkerAsync
            var data = "";
            var readByteCount = 0;
           


            do 
            {
                try
                {
                    readByteCount = sr.Read(charArray, 0, charArray.Length);

                }

                catch
                {
                    readByteCount = 0;
                }

                if (readByteCount > 0)
                {

                    data = new string(charArray, 0, readByteCount);
                    Console.WriteLine(data);
                    //Invoke(new Action(() => listBox1.Items.Add("server: " + data)));
                    if (data == "Great")
                    {                
                        Invoke(new Action(() => already_created=false));
                        Form1 newform = new Form1(client);
                        //Invoke(new Action(() => this.Hide() ));                       
                        Invoke(new Action(() => newform.ShowDialog()));
                        /*try
                        {
                            this.Close();
                        }
                        catch
                        {
                            Console.WriteLine("Not closed");
                        }*/
                        

                    }

                    else if(data== "already_created")
                    {
                        Invoke(new Action(() => already_created=true));
                        Form1 newform = new Form1(client);            
                        //Invoke(new Action(() => this.Hide() ));
                        Invoke(new Action(() => newform.ShowDialog()));
                       /* try
                        {
                            this.Close();
                        }
                        catch
                        {
                            Console.WriteLine("Not closed");
                        }*/


                    }

                    else if (data == "If you are a new user: Name already taken, please pick a new one. \n if not, wrong password")
                    {
                        Invoke(new Action(() => listBox1.Items.Clear() ));
                        Invoke(new Action(() => listBox1.Items.Add(data) ));
                        Invoke(new Action(() => label2.ForeColor = Color.Black));
                        Invoke(new Action(() => label1.ForeColor= Color.Red ));
                    }

                    else if (data == "Name must be at least 2 characters")
                    {
                        Invoke(new Action(() => listBox1.Items.Clear()));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                        Invoke(new Action(() => label2.ForeColor = Color.Black));
                        Invoke(new Action(() => label1.ForeColor = Color.Red));
                    }

                    else if (data == "password must be at least 2 characters")
                    {
                        Invoke(new Action(() => listBox1.Items.Clear()));
                        Invoke(new Action(() => listBox1.Items.Add(data)));
                        Invoke(new Action(() => label1.ForeColor = Color.Black));
                        Invoke(new Action(() => label2.ForeColor = Color.Red));
                    }

                    else if (data == "The test is over you cant connect")
                    {
                        Invoke(new Action(() => listBox1.Items.Clear()));
                        Invoke(new Action(() => listBox1.Items.Add(data)));

                    }
                    


                }
                else Thread.Sleep(100);
                Console.WriteLine(data);
            }
            while (data != "bye");
            Invoke(new Action(() => label1.Text = "connection terminated"));
        
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            client.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string msg = textBox1.Text;
            user_name = textBox1.Text;
            user_password = textBox2.Text;

            //msg example: "user-Noam-pong3"
            if (user_name != "")
                sw.WriteLine("user" + '-' + user_name + '-' + user_password);
        }

/*        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                button1_Click(sender, e);
        }*/

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
                button1_Click(sender, e);
        }
    }
}
