﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;

namespace Admin
{
    public partial class Form2 : Form
    {
        TcpClient client; // socket client
        StreamWriter sw;  // streamWriter
        StreamReader sr;  // streamReader
        char[] charArray = new char[1000]; // read char array
        int Time_till_hint = 20;
        bool Hints = true;
        int port = Form1.port;

        public Form2()
        {
            InitializeComponent();

            client = new TcpClient();
            client.Connect(new IPEndPoint(IPAddress.Parse("192.168.1.28"), port));
            sw = new StreamWriter(client.GetStream()); sw.AutoFlush = true;
            sr = new StreamReader(client.GetStream());
            backgroundWorker1.RunWorkerAsync(sr);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // time:5
            string msg = textBox1.Text;
            //example: 'Time_to_hint:10'
            if (msg.Contains("Time_till_hint:") && msg.Length>15)
            {
                int new_time;
                string time = msg.Substring(15, msg.Length - 15);
                bool isNumeric = int.TryParse(time, out new_time);
                //int new_time = int.TryParse (msg.Substring(15, msg.Length-15) ) ;
                Console.WriteLine((new_time).ToString() + "- the new time");

                if (new_time > 0 && new_time < 80)
                {
                    label3.Text = new_time.ToString();
                    //+ "Time_till_hint:"+ new_time
                    sw.WriteLine("Admin_"+ msg );
                }
                    
                else
                    listBox1.Items.Add("Error- You need to enter a number between 0-80");

            }
                  
            else if (msg.Contains("Hints:"))
            {
                string hinted = msg.Substring(6, msg.Length-6);
                Console.WriteLine(hinted + "- hinted");

                if (hinted == "False" || hinted== "True" )
                {
                    label4.Text = hinted;
                    sw.WriteLine("Admin_" + msg);
                }
                   
                else
                    listBox1.Items.Add("Error- You need to enter False/True");

            }
            


        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            StreamReader sr = e.Argument as StreamReader; // get streamReader argument from runWorkerAsync
            var data = "";
            var readByteCount = 0;

            do
            {

                readByteCount = sr.Read(charArray, 0, charArray.Length);

                if (readByteCount > 0)
                {
                    
                    data = new string(charArray, 0, readByteCount);
                    //example: Invoke(new Action(() => listBox1.Items.Add("server: " + data)));
                    Console.WriteLine("data--->" + data);
                    if (data == "bad input")
                        Invoke(new Action(() => listBox1.Items.Add("server: " + data)));



                }
                else Thread.Sleep(100);
                Console.WriteLine(data);
            }
            while (data != "bye");
            Invoke(new Action(() => listBox1.Items.Add("connection terminated") ));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = button3.Text;
            listBox1.Items.Add("Insert time till hint (0-80)");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = button4.Text;
            listBox1.Items.Add("Insert True/False");
        }

    }
    
}
