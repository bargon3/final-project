﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

namespace Admin
{
    public partial class Form1 : Form
    {
        TcpClient client; // socket client
        StreamWriter sw;  // streamWriter
        StreamReader sr;  // streamReader
        char[] charArray = new char[1000]; // read char array
        public static int port = 57761;
        int ticks;

        /// <summary>
        /// belongs to the share screen
        /// </summary>
        public static Bitmap bmpScreenshot;
        public bool start = false;
        public static Graphics gfxScreenshot;
        int countRead = 0, countWrite = 0;

        TcpClient client2 = null;
        TcpListener socket = null;

        public Form1()
        {
            InitializeComponent();

            client = new TcpClient();
            client.Connect(new IPEndPoint(IPAddress.Parse("192.168.1.28"), port));
            sw = new StreamWriter(client.GetStream()); sw.AutoFlush = true;
            sr = new StreamReader(client.GetStream());
            label1.Text = "connection established";
            timer1.Start();
            backgroundWorker1.RunWorkerAsync(sr);
        }

        private void button1_clicked(object sender, EventArgs e)
        {

            // sending example  sw.WriteLine(My_level.Text + "-" + listBox1.Items[1] + "-" + textBox1.Text);
            Console.WriteLine("Enterted get status");
            sw.WriteLine("Admin_update");
            listBox1.Items.Add("\n");

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e) // receive msg
        {
            StreamReader sr = e.Argument as StreamReader; // get streamReader argument from runWorkerAsync
            var data = "";
            var readByteCount = 0;
            string[] details; string id; string name; string subject; string grade; string current_level; string history;
            Console.WriteLine("qweweqwqe");


            do
            {

                readByteCount = sr.Read(charArray, 0, charArray.Length);

                if (readByteCount > 0)
                {
                    Console.WriteLine("deqdidwqi");
                    data = new string(charArray, 0, readByteCount);
                    //example: Invoke(new Action(() => listBox1.Items.Add("server: " + data)));

                    //Console.WriteLine(data);
                    details = data.Split('/');
                    int amount = details.Length;
                    /*  
                    id = details[0];
                    name = details[1];
                    subject = details[2];
                    grade = details[3];
                    current_level = details[4];
                    history = details[5];
                    */
                    for (int i = 0; i < amount; i++)
                    {
                        Invoke(new Action(() => listBox1.Items.Add(details[i])));
                    }
                   


                }
                else Thread.Sleep(100);
                Console.WriteLine(data);
            }
            while (data != "bye");
            Invoke(new Action(() => label1.Text = "connection terminated"));
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            client.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 newform = new Form2();
            newform.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ticks++;
            if (ticks == 20)
            {
                Console.WriteLine("TIme to update");
                ticks = 0;
                button1_clicked(sender, e);
            }

        }
//-------------------------------------------------------------------------------------------------------------------- share screens

        // start button- starting sharing screens
        private void button3_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;
            this.start = true;
            recievingWorker.RunWorkerAsync(); // run client
        }

        public void imageFromByteArray(byte[] arr)
        { // bytearray to image and display in picturebox
            countRead++;
            //Console.WriteLine("converting byte array to picturebox {0}", countRead);
            MemoryStream mStream = new MemoryStream();
            mStream.Write(arr, 0, Convert.ToInt32(arr.Length));
            pictureBox1.Image = new Bitmap(mStream, false);
            mStream.Dispose();
        }


        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            // connection--->
            //Console.WriteLine("start server");
            TcpListener serverSocket = new TcpListener(IPAddress.Parse("192.168.1.28"), 60001);
            serverSocket.Start();
            Console.WriteLine("started socket");
            TcpClient client = serverSocket.AcceptTcpClient();
            Console.WriteLine("receive tcp by server");
            this.client2 = client;
            this.socket = serverSocket;

            while (true)
            {
                NetworkStream netStream = client.GetStream();
                if (netStream.DataAvailable)
                {

                    BinaryFormatter bf = new BinaryFormatter();
                    byte[] bytes = (byte[])bf.Deserialize(netStream);
                    imageFromByteArray(bytes);

                }
            }
        
        }
    }
}
